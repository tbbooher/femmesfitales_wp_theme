<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpress');

/** MySQL database password */
define('DB_PASSWORD', '1ln48vnu');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@$$r-Vn:5~m6T]3`{hW?9ZGtpxixWZ[gZ_@+e564=/^+V;LIMl`]h?y?<uX8K9y!');
define('SECURE_AUTH_KEY',  'V{$E2Bht|lgFk7qU]4+d3>+Re-IhIhg5{%*D:% L[-Yjoy]Eun]:PT*LC>}$}K)(');
define('LOGGED_IN_KEY',    'Im)(+1A)P||(/N+F|M<(APCi/&MnVrBC.oyG{.+D[KJv}$BV.Jusnnd@dS!..e_d');
define('NONCE_KEY',        '8-<&Q:(C;}1:9$7=e8Kx?:QEj2s>i+v^WsD?-351_n.;:|;Os1^uJjmywP#*O@lc');
define('AUTH_SALT',        '8Vucfv=A-2l~gl*j_]0Z8_iXtUjuzECqbr#r/$s19WT62T~fPG<)F&~,8dJ Kd:V');
define('SECURE_AUTH_SALT', '^%y(=]B7Pm,u-d<K_3!XEH9]Z4pr~c$X5yIna0{.y8fN4+z@B8-5hwZ[kQiQp!5`');
define('LOGGED_IN_SALT',   '#=xOn->i&$:Ro!od4c*+r|O}H@Qn)~R1Q>#h<C/ !SoqVDF2zz+M_`?$0jZsQ# _');
define('NONCE_SALT',       '8wHgAT,OO?A2hc#!9L).O}dn]9b0e{ xS9E_PxHsju2+gdj4%i)f+<#3}KeIMTQ-');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_femme_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
